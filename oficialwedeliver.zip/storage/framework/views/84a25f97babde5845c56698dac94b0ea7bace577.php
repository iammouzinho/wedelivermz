<footer class="footer">
    <div class="px-4">
        <span class="text-muted">Todos Diretos Reservados © <?php echo e(date("Y")); ?> - WEDELIVERMZ</span>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\oficialwedeliver\resources\views/front/auth/layouts/footer.blade.php ENDPATH**/ ?>