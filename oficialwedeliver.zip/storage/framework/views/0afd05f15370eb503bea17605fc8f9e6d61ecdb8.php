
<script src="<?php echo e(URL::to('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?><?php /**PATH C:\xampp\htdocs\oficialwedeliver\resources\views/front/layouts/script.blade.php ENDPATH**/ ?>