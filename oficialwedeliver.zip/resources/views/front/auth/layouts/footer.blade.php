<footer class="footer">
    <div class="px-4">
        <span class="text-muted">Todos Diretos Reservados © {{date("Y")}} - WEDELIVERMZ</span>
    </div>
</footer>