<script src="{{URL::to('js/app.js')}}"></script>
@yield('scripts')